"""Realtime delivery boundary."""
