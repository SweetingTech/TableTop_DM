#!/usr/bin/env python3
"""
codex_iterate.py

Iterates through a codebase in batches and runs Codex against each batch.

Default mode:
  - read-only review
  - writes reports to .codex_iterate/reports/

Apply mode:
  - allows Codex to edit files inside the workspace using --sandbox workspace-write
  - still tells Codex to keep changes scoped to the current batch

Requirements:
  - Python 3.9+
  - Codex CLI installed and authenticated:
      npm i -g @openai/codex
      codex
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


DEFAULT_EXTENSIONS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".css",
    ".scss",
    ".html",
    ".json",
    ".yaml",
    ".yml",
    ".md",
    ".sql",
    ".sh",
    ".ps1",
    ".cs",
    ".java",
    ".go",
    ".rs",
    ".php",
    ".rb",
    ".vue",
    ".svelte",
}

DEFAULT_IGNORE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "dist",
    "build",
    ".next",
    ".nuxt",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".idea",
    ".vscode",
    "coverage",
    ".turbo",
    ".cache",
}

DEFAULT_IGNORE_FILES = {
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "poetry.lock",
    "Cargo.lock",
}


@dataclass
class CodeFile:
    path: Path
    size: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Batch a repo and run Codex iteratively over the codebase."
    )

    parser.add_argument(
        "--repo",
        default=".",
        help="Path to the repository root. Default: current directory.",
    )

    parser.add_argument(
        "--task",
        required=True,
        help=(
            "What Codex should do per batch. Example: "
            "'Review for bugs, duplicated logic, missing tests, and unsafe assumptions.'"
        ),
    )

    parser.add_argument(
        "--apply",
        action="store_true",
        help="Allow Codex to edit files in the workspace using --sandbox workspace-write.",
    )

    parser.add_argument(
        "--model",
        default=None,
        help="Optional Codex model override, e.g. gpt-5.5 or gpt-5.4-mini.",
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=20,
        help="Max number of files per Codex pass. Default: 20.",
    )

    parser.add_argument(
        "--max-file-kb",
        type=int,
        default=256,
        help="Skip individual files larger than this size in KB. Default: 256.",
    )

    parser.add_argument(
        "--include-ext",
        nargs="*",
        default=None,
        help="Optional extension allowlist, e.g. --include-ext .py .ts .tsx",
    )

    parser.add_argument(
        "--ignore-dir",
        nargs="*",
        default=[],
        help="Extra directory names to ignore.",
    )

    parser.add_argument(
        "--ignore-pattern",
        nargs="*",
        default=[],
        help="Extra fnmatch patterns to ignore, e.g. '*.generated.ts' 'migrations/*'",
    )

    parser.add_argument(
        "--out",
        default=".codex_iterate",
        help="Output directory for reports and run metadata. Default: .codex_iterate",
    )

    return parser.parse_args()


def should_ignore_path(
    rel_path: Path,
    ignore_dirs: set[str],
    ignore_files: set[str],
    ignore_patterns: list[str],
) -> bool:
    parts = set(rel_path.parts)

    if parts & ignore_dirs:
        return True

    if rel_path.name in ignore_files:
        return True

    rel_str = rel_path.as_posix()
    return any(fnmatch.fnmatch(rel_str, pattern) for pattern in ignore_patterns)


def discover_files(
    repo: Path,
    extensions: set[str],
    ignore_dirs: set[str],
    ignore_files: set[str],
    ignore_patterns: list[str],
    max_file_kb: int,
) -> list[CodeFile]:
    files: list[CodeFile] = []
    max_bytes = max_file_kb * 1024

    for root, dirs, filenames in os.walk(repo):
        root_path = Path(root)

        # Mutate dirs in-place so os.walk does not descend into ignored directories.
        dirs[:] = [d for d in dirs if d not in ignore_dirs]

        for filename in filenames:
            full_path = root_path / filename
            rel_path = full_path.relative_to(repo)

            if should_ignore_path(rel_path, ignore_dirs, ignore_files, ignore_patterns):
                continue

            if full_path.suffix.lower() not in extensions:
                continue

            try:
                size = full_path.stat().st_size
            except OSError:
                continue

            if size > max_bytes:
                continue

            files.append(CodeFile(path=rel_path, size=size))

    return sorted(files, key=lambda f: f.path.as_posix())


def chunk_files(files: list[CodeFile], batch_size: int) -> Iterable[list[CodeFile]]:
    for index in range(0, len(files), batch_size):
        yield files[index : index + batch_size]


def make_prompt(
    task: str,
    batch_number: int,
    total_batches: int,
    batch: list[CodeFile],
    apply: bool,
) -> str:
    file_list = "\n".join(
        f"- {item.path.as_posix()} ({item.size} bytes)" for item in batch
    )

    mode_rules = (
        """
You may edit files, but only when the edit directly supports the task.
Keep edits scoped to the files listed in this batch unless another file is absolutely required.
If you touch an unlisted file, explain why in the final report.
Run relevant tests or static checks when practical.
"""
        if apply
        else """
Do not edit files.
Review only.
Return findings, risks, and concrete recommended changes.
"""
    ).strip()

    return f"""
You are iterating through a codebase in batches.

Batch: {batch_number} of {total_batches}

User task:
{task}

Files for this batch:
{file_list}

Rules:
{mode_rules}

Required final output:
1. Batch summary
2. Files inspected
3. Findings, grouped by severity: Critical, High, Medium, Low
4. Concrete next actions
5. If no issues are found, say that clearly and explain what you checked

Do not wander the whole repo like a caffeinated raccoon. Start with the listed files.
""".strip()


def run_codex(
    repo: Path,
    prompt: str,
    output_path: Path,
    apply: bool,
    model: str | None,
) -> int:
    cmd = [
        "codex",
        "exec",
        "--cd",
        str(repo),
        "--ephemeral",
        "--output-last-message",
        str(output_path),
    ]

    if model:
        cmd.extend(["--model", model])

    if apply:
        cmd.extend(["--sandbox", "workspace-write"])

    cmd.append(prompt)

    print(f"\nRunning: {' '.join(cmd[:8])} ...")
    result = subprocess.run(cmd, text=True)

    return result.returncode


def main() -> int:
    args = parse_args()

    repo = Path(args.repo).resolve()
    if not repo.exists() or not repo.is_dir():
        print(
            f"Repo path does not exist or is not a directory: {repo}", file=sys.stderr
        )
        return 2

    extensions = set(args.include_ext) if args.include_ext else DEFAULT_EXTENSIONS
    extensions = {ext if ext.startswith(".") else f".{ext}" for ext in extensions}

    ignore_dirs = DEFAULT_IGNORE_DIRS | set(args.ignore_dir)
    ignore_files = DEFAULT_IGNORE_FILES

    out_dir = repo / args.out
    reports_dir = out_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    files = discover_files(
        repo=repo,
        extensions=extensions,
        ignore_dirs=ignore_dirs,
        ignore_files=ignore_files,
        ignore_patterns=args.ignore_pattern,
        max_file_kb=args.max_file_kb,
    )

    if not files:
        print(
            "No matching files found. Either your filters are too tight or the repo is a desert."
        )
        return 1

    batches = list(chunk_files(files, args.batch_size))

    manifest = {
        "repo": str(repo),
        "task": args.task,
        "apply": args.apply,
        "model": args.model,
        "batch_size": args.batch_size,
        "max_file_kb": args.max_file_kb,
        "total_files": len(files),
        "total_batches": len(batches),
        "files": [f.path.as_posix() for f in files],
    }

    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(f"Repo: {repo}")
    print(f"Files selected: {len(files)}")
    print(f"Batches: {len(batches)}")
    print(f"Mode: {'APPLY / workspace-write' if args.apply else 'READ-ONLY REVIEW'}")
    print(f"Reports: {reports_dir}")

    failures = 0

    for idx, batch in enumerate(batches, start=1):
        report_path = reports_dir / f"batch_{idx:03d}.md"
        prompt = make_prompt(
            task=args.task,
            batch_number=idx,
            total_batches=len(batches),
            batch=batch,
            apply=args.apply,
        )

        rc = run_codex(
            repo=repo,
            prompt=prompt,
            output_path=report_path,
            apply=args.apply,
            model=args.model,
        )

        if rc != 0:
            failures += 1
            print(f"Batch {idx} failed with exit code {rc}", file=sys.stderr)
        else:
            print(f"Batch {idx} complete: {report_path}")

    summary_prompt = f"""
You just completed a batched codebase iteration.

Read the reports in:
{reports_dir.relative_to(repo).as_posix()}

Create a final consolidated summary at:
{out_dir.relative_to(repo).as_posix()}/FINAL_SUMMARY.md

The summary must include:
1. Overall architecture observations
2. Top recurring issues
3. Highest priority fixes
4. Files or modules needing deeper review
5. Suggested next Codex prompt for the next iteration

Do not invent findings. Use only the batch reports.
""".strip()

    final_report_path = out_dir / "FINAL_SUMMARY.md"

    print("\nCreating consolidated summary...")
    rc = run_codex(
        repo=repo,
        prompt=summary_prompt,
        output_path=final_report_path,
        apply=True,
        model=args.model,
    )

    if rc != 0:
        failures += 1
        print(f"Final summary failed with exit code {rc}", file=sys.stderr)

    if failures:
        print(
            f"\nCompleted with {failures} failed Codex runs. Because naturally even automation needs supervision."
        )
        return 1

    print(f"\nDone. Final summary: {final_report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
